import { useContext, useState } from "react";
import { CVContext } from "../context/CVContext";
import useFormValidation from "../hooks/useFormValidation";
import { v4 as uuid } from "uuid";

function ProjectForm() {
  const { cvData, setCvData } = useContext(CVContext);
  const { validate } = useFormValidation();

  const [form, setForm] = useState({
    nombre: "",
    descripcion: "",
    tecnologias: "",
    repositorio: "",
    deploy: "",
    imagen: ""
  });

  const [editingId, setEditingId] = useState(null);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const resetForm = () => {
    setForm({
      nombre: "",
      descripcion: "",
      tecnologias: "",
      repositorio: "",
      deploy: "",
      imagen: ""
    });
    setEditingId(null);
    setErrors({});
  };

  const addProject = (e) => {
    e.preventDefault();

    const validationErrors = validate("project", form, cvData.projects);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setCvData(prev => ({
      ...prev,
      projects: [...prev.projects, { id: uuid(), ...form }]
    }));

    resetForm();
  };

  const editProject = (p) => {
    setForm(p);
    setEditingId(p.id);
  };

  const updateProject = (e) => {
    e.preventDefault();

    const validationErrors = validate("project", form, cvData.projects);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setCvData(prev => ({
      ...prev,
      projects: prev.projects.map(p =>
        p.id === editingId ? { ...p, ...form } : p
      )
    }));

    resetForm();
  };

  const deleteProject = (id) => {
    setCvData(prev => ({
      ...prev,
      projects: prev.projects.filter(p => p.id !== id)
    }));
  };

  return (
    <div>
      <form onSubmit={editingId ? updateProject : addProject}>
        <h2>Proyectos</h2>

        <input name="nombre" value={form.nombre} onChange={handleChange} />
        <input name="descripcion" value={form.descripcion} onChange={handleChange} />
        <input name="tecnologias" value={form.tecnologias} onChange={handleChange} />
        <input name="repositorio" value={form.repositorio} onChange={handleChange} />
        <input name="deploy" value={form.deploy} onChange={handleChange} />

        <button type="submit">
          {editingId ? "Actualizar" : "Agregar"}
        </button>
      </form>

      {cvData.projects.map(p => (
        <div key={p.id}>
          {p.nombre}

          <button onClick={() => editProject(p)}>Editar</button>
          <button onClick={() => deleteProject(p.id)}>Eliminar</button>
        </div>
      ))}
    </div>
  );
}

export default ProjectForm;