import { useContext, useState } from "react";
import { CVContext } from "../context/CVContext";
import useFormValidation from "../hooks/useFormValidation";
import { v4 as uuid } from "uuid";

function SkillForm() {
  const { cvData, setCvData } = useContext(CVContext);
  const { validate } = useFormValidation();

  const [form, setForm] = useState({
    nombre: "",
    categoria: "",
    nivel: 50,
    descripcion: ""
  });

  const [editingId, setEditingId] = useState(null);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };

  const resetForm = () => {
    setForm({
      nombre: "",
      categoria: "",
      nivel: 50,
      descripcion: ""
    });
    setEditingId(null);
    setErrors({});
  };

  // CREATE
  const addSkill = (e) => {
    e.preventDefault();

    const validationErrors = validate("skill", form, cvData.skills);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setCvData(prev => ({
      ...prev,
      skills: [
        ...prev.skills,
        { id: uuid(), ...form, nivel: Number(form.nivel) }
      ]
    }));

    resetForm();
  };

  // EDIT
  const editSkill = (skill) => {
    setForm(skill);
    setEditingId(skill.id);
  };

  // UPDATE
  const updateSkill = (e) => {
    e.preventDefault();

    const validationErrors = validate("skill", form, cvData.skills);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setCvData(prev => ({
      ...prev,
      skills: prev.skills.map(s =>
        s.id === editingId
          ? { ...s, ...form, nivel: Number(form.nivel) }
          : s
      )
    }));

    resetForm();
  };

  // DELETE
  const deleteSkill = (id) => {
    setCvData(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s.id !== id)
    }));
  };

  return (
    <div>
      <form onSubmit={editingId ? updateSkill : addSkill}>
        <h2>Skills</h2>

        <input name="nombre" value={form.nombre} onChange={handleChange} />
        {errors.nombre && <p>{errors.nombre}</p>}

        <input name="categoria" value={form.categoria} onChange={handleChange} />

        <input name="nivel" type="number" value={form.nivel} onChange={handleChange} />
        {errors.nivel && <p>{errors.nivel}</p>}

        <input name="descripcion" value={form.descripcion} onChange={handleChange} />

        <button type="submit">
          {editingId ? "Actualizar" : "Agregar"}
        </button>
      </form>

      {cvData.skills.map(s => (
        <div key={s.id}>
          {s.nombre} - {s.nivel}%

          <button onClick={() => editSkill(s)}>Editar</button>
          <button onClick={() => deleteSkill(s.id)}>Eliminar</button>
        </div>
      ))}
    </div>
  );
}

export default SkillForm;