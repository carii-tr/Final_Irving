import { useContext } from "react";
import { CVContext } from "../context/CVContext";

function CVPreview() {
    const { cvData } = useContext(CVContext);
    const { personal, skills, projects, education, languages } = cvData;

    return (
        <div
            id="cv-preview"
            style={{ padding: "20px", background: "white" }}
        >

            {/* ================= PERSONAL ================= */}
            <section>
                <h1>{personal.nombre || "Nombre no definido"}</h1>
                <h3>{personal.profesion}</h3>
                <p>{personal.ciudad}</p>
                <p>{personal.descripcion}</p>

                <p>{personal.correo}</p>
                <p>{personal.telefono}</p>

                <div>
                    {personal.github && (
                        <a href={personal.github} target="_blank" rel="noreferrer">
                            GitHub
                        </a>
                    )}

                    {" "}

                    {personal.linkedin && (
                        <a href={personal.linkedin} target="_blank" rel="noreferrer">
                            LinkedIn
                        </a>
                    )}
                </div>

                {personal.imagen && (
                    <img
                        src={personal.imagen}
                        alt="perfil"
                        width="120"
                    />
                )}
            </section>

            <hr />

            {/* ================= SKILLS ================= */}
            <section>
                <h2>Habilidades</h2>

                {skills.length === 0 ? (
                    <p>Sin habilidades</p>
                ) : (
                    skills.map((s) => (
                        <div key={s.id}>
                            <strong>{s.nombre}</strong>

                            <div style={{ width: "200px", background: "#ddd" }}>
                                <div
                                    style={{
                                        width: `${s.nivel}%`,
                                        background: "#4f46e5",
                                        color: "white"
                                    }}
                                >
                                    {s.nivel}%
                                </div>
                            </div>

                            <small>{s.categoria}</small>
                        </div>
                    ))
                )}
            </section>

            <hr />

            {/* ================= PROJECTS ================= */}
            <section>
                <h2>Proyectos</h2>

                {projects.length === 0 ? (
                    <p>Sin proyectos</p>
                ) : (
                    projects.map((p) => (
                        <div key={p.id}>
                            <h3>{p.nombre}</h3>
                            <p>{p.descripcion}</p>
                            <p>{p.tecnologias}</p>

                            {p.repositorio && (
                                <a href={p.repositorio} target="_blank" rel="noreferrer">
                                    Repo
                                </a>
                            )}

                            {" "}

                            {p.deploy && (
                                <a href={p.deploy} target="_blank" rel="noreferrer">
                                    Deploy
                                </a>
                            )}
                        </div>
                    ))
                )}
            </section>

            <hr />

            {/* ================= EDUCATION ================= */}
            <section>
                <h2>Educación</h2>

                {education.length === 0 ? (
                    <p>Sin educación</p>
                ) : (
                    education.map((e) => (
                        <div key={e.id}>
                            <h3>{e.institucion}</h3>
                            <p>{e.programa}</p>
                            <p>{e.periodo}</p>
                            <p>{e.descripcion}</p>
                        </div>
                    ))
                )}
            </section>

            <hr />

            {/* ================= LANGUAGES ================= */}
            <section>
                <h2>Idiomas</h2>

                {languages.length === 0 ? (
                    <p>Sin idiomas</p>
                ) : (
                    languages.map((l) => (
                        <div key={l.id}>
                            <strong>{l.idioma}</strong> - {l.nivel}
                            <p>{l.descripcion}</p>
                        </div>
                    ))
                )}
            </section>

        </div>
    );
}

export default CVPreview;