import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav style={{
      display: "flex",
      gap: "15px",
      padding: "10px",
      borderBottom: "1px solid #ccc"
    }}>
      <Link to="/">Home</Link>
      <Link to="/editor">Editor</Link>
      <Link to="/dashboard">Dashboard</Link>
      <Link to="/preview">Preview</Link>
      <Link to="/about">About</Link>
    </nav>
  );
}

export default Navbar;