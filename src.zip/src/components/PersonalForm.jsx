import { useContext, useState } from "react";
import { CVContext } from "../context/CVContext";
import useFormValidation from "../hooks/useFormValidation";

function PersonalForm() {
    const { cvData, setCvData } = useContext(CVContext);
    const { validate } = useFormValidation();

    const [form, setForm] = useState(cvData.personal);
    const [errors, setErrors] = useState({});

    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        const validationErrors = validate("personal", form);
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length > 0) return;

        setCvData(prev => ({
            ...prev,
            personal: form
        }));
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Datos personales</h2>

            <input name="nombre" placeholder="Nombre" value={form.nombre} onChange={handleChange} />
            {errors.nombre && <p>{errors.nombre}</p>}

            <input name="profesion" placeholder="Profesión" value={form.profesion} onChange={handleChange} />
            {errors.profesion && <p>{errors.profesion}</p>}

            <input name="ciudad" placeholder="Ciudad" value={form.ciudad} onChange={handleChange} />

            <input name="correo" placeholder="Correo" value={form.correo} onChange={handleChange} />
            {errors.correo && <p>{errors.correo}</p>}

            <input name="telefono" placeholder="Teléfono" value={form.telefono} onChange={handleChange} />

            <textarea name="descripcion" placeholder="Descripción" value={form.descripcion} onChange={handleChange} />

            <input name="github" placeholder="GitHub" value={form.github} onChange={handleChange} />
            <input name="linkedin" placeholder="LinkedIn" value={form.linkedin} onChange={handleChange} />
            <input name="imagen" placeholder="URL imagen" value={form.imagen} onChange={handleChange} />

            <button type="submit">Guardar</button>
        </form>
    );
}

export default PersonalForm;