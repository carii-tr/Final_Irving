import { useContext, useState } from "react";
import { CVContext } from "../context/CVContext";
import useFormValidation from "../hooks/useFormValidation";
import { v4 as uuid } from "uuid";

function EducationForm() {
    const { cvData, setCvData } = useContext(CVContext);
    const { validate } = useFormValidation();

    const [form, setForm] = useState({
        institucion: "",
        programa: "",
        periodo: "",
        descripcion: "",
        evidencia: ""
    });

    const [editingId, setEditingId] = useState(null);
    const [errors, setErrors] = useState({});

    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };

    const resetForm = () => {
        setForm({
            institucion: "",
            programa: "",
            periodo: "",
            descripcion: "",
            evidencia: ""
        });
        setEditingId(null);
        setErrors({});
    };

    // CREATE
    const addEducation = (e) => {
        e.preventDefault();

        const validationErrors = validate("education", form, cvData.education);
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length > 0) return;

        setCvData(prev => ({
            ...prev,
            education: [
                ...prev.education,
                { id: uuid(), ...form }
            ]
        }));

        resetForm();
    };

    // EDIT
    const editEducation = (item) => {
        setForm(item);
        setEditingId(item.id);
    };

    // UPDATE
    const updateEducation = (e) => {
        e.preventDefault();

        const validationErrors = validate("education", form, cvData.education);
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length > 0) return;

        setCvData(prev => ({
            ...prev,
            education: prev.education.map(e =>
                e.id === editingId ? { ...e, ...form } : e
            )
        }));

        resetForm();
    };

    // DELETE
    const deleteEducation = (id) => {
        setCvData(prev => ({
            ...prev,
            education: prev.education.filter(e => e.id !== id)
        }));
    };

    return (
        <div>
            <form onSubmit={editingId ? updateEducation : addEducation}>
                <h2>Educación</h2>

                <input
                    name="institucion"
                    value={form.institucion}
                    onChange={handleChange}
                    placeholder="Institución"
                />
                {errors.institucion && <p>{errors.institucion}</p>}

                <input
                    name="programa"
                    value={form.programa}
                    onChange={handleChange}
                    placeholder="Programa"
                />
                {errors.programa && <p>{errors.programa}</p>}

                <input
                    name="periodo"
                    value={form.periodo}
                    onChange={handleChange}
                    placeholder="Periodo"
                />
                {errors.periodo && <p>{errors.periodo}</p>}
                <input
                    name="descripcion"
                    value={form.descripcion}
                    onChange={handleChange}
                    placeholder="Descripción"
                />
                {errors.descripcion && <p>{errors.descripcion}</p>}

                <button type="submit">
                    {editingId ? "Actualizar" : "Agregar"}
                </button>
            </form>

            {cvData.education.map(e => (
                <div key={e.id}>
                    <strong>{e.institucion}</strong>

                    <button onClick={() => editEducation(e)}>Editar</button>
                    <button onClick={() => deleteEducation(e.id)}>Eliminar</button>
                </div>
            ))}
        </div>
    );
}

export default EducationForm;