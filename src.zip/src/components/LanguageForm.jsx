import { useContext, useState } from "react";
import { CVContext } from "../context/CVContext";
import useFormValidation from "../hooks/useFormValidation";
import { v4 as uuid } from "uuid";

function LanguageForm() {
    const { cvData, setCvData } = useContext(CVContext);
    const { validate } = useFormValidation();

    const [form, setForm] = useState({
        idioma: "",
        nivel: "",
        descripcion: ""
    });

    const [editingId, setEditingId] = useState(null);
    const [errors, setErrors] = useState({});

    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };

    const resetForm = () => {
        setForm({
            idioma: "",
            nivel: "",
            descripcion: ""
        });
        setEditingId(null);
        setErrors({});
    };

    // CREATE
    const addLanguage = (e) => {
        e.preventDefault();

        const validationErrors = validate("language", form, cvData.languages);
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length > 0) return;

        setCvData(prev => ({
            ...prev,
            languages: [
                ...prev.languages,
                { id: uuid(), ...form }
            ]
        }));

        resetForm();
    };

    // EDIT
    const editLanguage = (item) => {
        setForm(item);
        setEditingId(item.id);
    };

    // UPDATE
    const updateLanguage = (e) => {
        e.preventDefault();

        const validationErrors = validate("language", form, cvData.languages);
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length > 0) return;

        setCvData(prev => ({
            ...prev,
            languages: prev.languages.map(l =>
                l.id === editingId ? { ...l, ...form } : l
            )
        }));

        resetForm();
    };

    // DELETE
    const deleteLanguage = (id) => {
        setCvData(prev => ({
            ...prev,
            languages: prev.languages.filter(l => l.id !== id)
        }));
    };

    return (
        <div>
            <form onSubmit={editingId ? updateLanguage : addLanguage}>
                <h2>Idiomas</h2>

                <input
                    name="idioma"
                    value={form.idioma}
                    onChange={handleChange}
                    placeholder="Idioma"
                />
                {errors.idioma && <p>{errors.idioma}</p>}

                <input
                    name="nivel"
                    value={form.nivel}
                    onChange={handleChange}
                    placeholder="Nivel"
                />
                {errors.nivel && <p>{errors.nivel}</p>}

                <input
                    name="descripcion"
                    value={form.descripcion}
                    onChange={handleChange}
                    placeholder="Descripción"
                />
                {errors.descripcion && <p>{errors.descripcion}</p>}

                <button type="submit">
                    {editingId ? "Actualizar" : "Agregar"}
                </button>
            </form>

            {cvData.languages.map(l => (
                <div key={l.id}>
                    <strong>{l.idioma}</strong> - {l.nivel}

                    <button onClick={() => editLanguage(l)}>Editar</button>
                    <button onClick={() => deleteLanguage(l.id)}>Eliminar</button>
                </div>
            ))}
        </div>
    );
}

export default LanguageForm;