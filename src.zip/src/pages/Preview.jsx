import CVPreview from "../components/CVPreview";
import { generatePDF } from "../utils/pdfGenerator";

function Preview() {
  return (
    <div>
      <h1>Previsualización del CV</h1>

      <button
        onClick={generatePDF}
        style={{
          padding: "10px",
          marginBottom: "10px",
          cursor: "pointer"
        }}
      >
        📄 Exportar PDF
      </button>

      <CVPreview />
    </div>
  );
}

export default Preview;