import SkillChart from "../components/SkillChart";

function Dashboard() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Dashboard</h1>

      <p>Resumen de habilidades del CV</p>

      <SkillChart />
    </div>
  );
}

export default Dashboard;